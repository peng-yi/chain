/*
    program:    mymath.c
    author:     Peng Yi at MIT
    date:       April 10, 2007
    purpose:    my math functions which are heavily used in the program
*/

#define __MYMATH_MODULE
#include "mymath.h"
