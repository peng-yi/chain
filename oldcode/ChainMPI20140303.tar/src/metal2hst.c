/*
	program:	metal2hst.c
	author:		Peng Yi at JHU
	date:		Dec. 28, 2013
	purpose:	analyze LAMMPS dump file for metal simulations
	note:		require setup file
	update:
			Dec. 28, 2013	Created based on lammps2hst.c
*/

#define __MAIN_PROGRAM
#include "header.h"

#define M2HVERSION	"1/20/2014"
#define CAP		5		// largest nuclei considered still the melt
#define M2HDEBUG	0
#define SIZECAP		5
#define DEN_BIN		12
#define MAXNINPUTFILE	32

#undef CODE

//#include "correlation.h"		// autocorrelation calculation module, can consume a lot of memory

//==============================//
//	Global variables	//
//==============================//
long		timestep;
int 		nmaxp2_1[10];		// nmax using p2 nucleus definition
int 		nmaxp2_2[10];
int 		nmaxp2_3[10];
int 		nmaxp2_4[10];
float		rshift2;		// shift of the biggest nucleus

float		R02;
float		Rg2[MAXNMOLS];		// Radius of gyration square
float		aveRg2;			// average Rg2 for the system
float		avexRg2, avemRg2;	// average Rg2 for xtal and melt phases
int		nRg2, nxRg2;
vector		smoothresult;
float		rgx2[MAXNMOLS], rgy2[MAXNMOLS], rgz2[MAXNMOLS];
float		avergx2, avergy2, avergz2;

vector		com_sys,		// com of system
		com_sysinit,		// com of initial system
		com_syslast,		// com of previous system
		com_init[MAXNMOLS],	// com of each chain in the beginning
		com_last[MAXNMOLS];	// com of each chain in the previous dump
vector		dr_sys;			// vector of system drift
float		d2initave,		// average displacement w.r.t. to the beginning
		d2lastave,		// average displacement w.r.t. to previous dump
                d2sys, d2syslast;
float		asphericity;		// asphericity of the box

double		lam1, lam2, amo1, amo2;	// thickness of lamellae and interface
double		v2, vf2, vcom2;		// velocity and kinetic energy analysis

//==============================================//
//	Function Declarations and Definitions	//
//==============================================//
void 		output_xyzfile(FILE *);
int 		displayatom(int n);

//======================//
//	Main Program	//
//======================//
int main(int argc, char *argv[])
{
   time_t	t	=	time(NULL);
   time_t	prog_start, prog_end, start, end;
   molstruct	*moli;
   long		i, j, k, system, m, n, id, maxid, max, size;
   long		siteid, molid, type;
   int		nx, ny, nz, nx1, ny1, nz1;
   double	x, y, z, 			// coordinates
		vx, vy, vz, 			// velocity
		fx, fy, fz,			// force
		xhi, xlo, yhi, 			// box lower boundary
		ylo, zhi, zlo,			// box upper boundary
		xy=0.0, xz=0.0, yz=0.0;		// triclinic parameter
   long		LENGTH, accum;			// chain length variables

   // dummy variables
   
   int		itmp1, itmp2, itmp3;
   double	tmp1, tmp2, tmp3;

   // file variables
   
   char		infile[MAXNINPUTFILE][80], filein[80], filename[80], procid[16];
   char		s[80], ff[80], par[80], dummy[255];
   char		atomname;			// for visualization file output

   FILE		*fin, *fhst, *fpre;		// input and analysis output
   FILE		*fxyz;
   FILE		*fcolor;
   FILE		*fcar, *fconf, *fpdb, *fdat;	// configuration/visualization output
   FILE		*fZfile;			// Z-code input configuration file

   int		preflag		= 0;		// flags for input command line
   int		polydisperse	= 0;
   int		confflag	= 0;
   int		carflag		= 0;
   int		pdbflag		= 0;
   int		xyzflag		= 0;
   int		Zflag		= 0;
   int		nfiles=1;			// number of input files 
   int		ifile;				// index of input file
   int		nframe, dnframe=1;		// analyze only every dnframe
   int		previous_timestep=-1;
   int		starttime=-1;
   int		endtime=-1;

   static int	clistinit=1, cominit=1;	

   vector		con;			// center of nucleus
   static vector	rO;			// original position of nucleus

   // a group of beads
   
   vector	rbead[MAXNMOLS*MAXNMOLSITES];

   // variables to characterize nucleus, chains, etc at ONE timestep

   long		nsites;
   int 		nuclid;
   int		nmaxid;					// nuclid of the largest nucleus
   beadstruct	nucleus[MAXNMOLS*MAXNMOLSITES];		// group beads in the same nucleus
   vector	com[MAXNMOLS];				// average center of mass
   long		ncom[MAXNMOLS];
   int		nchainmax;				// # of chains in the largest nucleus

   // chain rotational angle distribution

   vector	chainface;
   double	orient;
   long		orientdist[180];

   // density profile

   long		direct;
   double	density[100];
   vector	rsite[MAXNMOLS * MAXNMOLSITES];	

   // velocity statistics
 
   double	dvel=0.001;
   double	ave_vx, ave_vy, ave_vz;
   double 	velmax=0.0, velmin=0.0;
   double	vel_distx[101], vel_disty[101], vel_distz[101];
 
   // variables to AVERAGE over a number of timesteps

   long		*Nn;				// size dist. of nucleus size
   long		ntot, maxnmax;			// total number of nuclei for normalization
   long		xbeadpos[MAXNMOLSITES];		// xtal bead position on chain
   float	avePtt, avePttt;		// prob. of 2 or 3 consecutive trans states
   float	stdPtt, stdPttt;
   float	*Rg2nucl;			// Rg2 of nucleus as a function of size

   // segment statistics variables

   int 		head, tail, seg_on, seg_id, nseg, nxtal, length;
   int 		segment[MAXNMOLS][MAXNMOLSITES];	// segments identification on a chain
							// -- segment[molid][siteid]
   int		ntail, nloop, nbridge, npbrdg, nxseg;	// # of tails, etc
   float	ltail, lloop, lbridge, lpbrdg, lxseg;	// average leng of tails, etc
   float	lfree;	
   int		lsegdist[10][MAXNMOLSITES];		// segment length distribution
   int		nltail[MAXNMOLSITES],			// tail length distribution
   		nlloop[MAXNMOLSITES], 			// loop
		nlbridge[MAXNMOLSITES],			// bridge
                nlpbrdg[MAXNMOLSITES],			// p.b.c bridge
		nlxseg[MAXNMOLSITES],			// xtal stem
		nlfree[MAXNMOLSITES];			// free chain
   int		oldxtal=0, oldnnucl=0,			// xtal variables before segment smoothing
                oldnmax=0, old2nmax=0;
   vector	rhead, rtail;

   // pbc image variables
   
   long		imagen=0;
   double	imagex, imagey, imagez;	

   //------MPI initialization------//
//   MPI_numprocs	=	1;			// default value
//   MPI_myid	=	0;			// default value

#ifdef myMPI
   MPI_Init(&argc, &argv);
   MPI_Comm_size(MPI_COMM_WORLD, &MPI_numprocs);
   MPI_Comm_rank(MPI_COMM_WORLD, &MPI_myid);
#endif

   if (argc<2 && MPI_myid==0) {
      printf("metal2hst (c) 2014 by Peng Yi at JHU\n\n");
      printf("Usage:\n");
      printf("\tmetal2hst [-option] [x= 0.1 y= 0.1 z= 0.1 n= 1] [dn= 2 nfiles= 2] lammpsdumpfile(s)\n\n");
      printf("Notes:\n");
      printf("\t* -option = \n");
      printf("\t* -pre: generate pre-analysis results\n");
      printf("\t* -poly: polydisperse system, has molid in dump file\n");
      printf("\t* -conf: configuration file output\n");
      printf("\t* -car: car file output\n");
      printf("\t* -pdb: pdb file output\n");
      printf("\t* -xyz: xyz file output\n");
      printf("\t* x= y= z=: duplicate the system and shift unit vector\n");
      printf("\t* n=: multiple of shift vector\n");
      printf("\t* start=: the timestep that analysis stops\n");
      printf("\t* end=: the timestep that analysis stops\n");
      printf("\t* dn=: only analyze every dn frames\n");
      printf("\t* nfiles=: number of input files if more than 1 (must be <=32)\n");
      printf("\t* \"=\" must immediately follow x or y or z or n or dn\n");
      printf("\t* require setup file\n\n");
      exit(1);
   }

   for (i=1; i<argc-1; i++) {
      strcpy(par, argv[i]);
      if(samestr(par, "-pre"))		preflag		=	1;
      else if (samestr(par, "-conf"))	confflag	=	1;
      else if (samestr(par, "-car"))	carflag		=	1;
      else if (samestr(par, "-pdb"))	pdbflag		=	1;
      else if (samestr(par, "-xyz"))	xyzflag		=	1;
      else if (samestr(par, "-Z"))	Zflag		=	1;
      else if (samestr(par, "x="))	imagex		=	atof(argv[i+1]);
      else if (samestr(par, "y=")) 	imagey		=	atof(argv[i+1]);
      else if (samestr(par, "z=")) 	imagez		=	atof(argv[i+1]);
      else if (samestr(par, "n=")) 	imagen		=	atol(argv[i+1]);
      else if (samestr(par, "start=")) 	starttime	=	atol(argv[i+1]);
      else if (samestr(par, "end=")) 	endtime		=	atol(argv[i+1]);
      else if (samestr(par, "dn=")) 	dnframe		=	atol(argv[i+1]);
      else if (samestr(par, "nfiles="))	nfiles		=	atoi(argv[i+1]);
   }
   if (nfiles > MAXNINPUTFILE) {
      printf("Error! number of input files exceeds MAXNINPUTFILE\n");
   }
   for (i=0; i<nfiles; i++) {
      strcpy(infile[nfiles-1-i], argv[argc-1-i]);	// get input filenames
   }

   //---------------------------//
   //	Open output files	//
   //---------------------------//
 
   if (nfiles==1)	strcpy(filein, infile[0]);	// determine output filename
   else			strcpy(filein, "multi");

   sprintf(procid, ".%d", MPI_myid);			// MPI: proc id for output files

#ifdef	myMPI
   //if (MPI_myid==0) {					// ONLY process 0 do the following
#endif

   //------Open optional output files------//

   if (xyzflag) {
      strcpy(filename, filein);
      strcat(filename, ".xyz");
      strcat(filename, procid);

      fxyz 	= 	fopen(filename, "w");
      fcolor	=	fopen("color", "w");
   }

#ifdef	myMPI
   //}
#endif

   if (!M2HDEBUG) {			
      strcpy(filename, filein);
      strcat(filename, ".out");			// every processor does output
      strcat(filename, procid);
      freopen(filename, "w", stdout);		// redirect standard output stream to a file
   }

   //------Write run info. to output file------//

   printf("# BEGINNING OF OUTPUT FILE\n");
   printf("%s\n", asctime(localtime(&t)));

   printf("# metal2hst version: %s\n", M2HVERSION);
   printf("# command: ");
   for (i=0; i<argc; i++) {	
      printf("%s ", argv[i]);	
   }
   printf("\n");
   printf("# number of processor:  %d\n", MPI_numprocs);
   printf("# id of this processor: %d\n", MPI_myid);
   printf("\n");

   prog_start	=	time(NULL);			// to calculate running time

   //-------------------//
   //	Initialization	//
   //-------------------//

   if (M2HDEBUG)	printf("DEBUG: Initialization ...\n");

   InitMols(MAXNMOLS, MAXNMOLS);	// allocate memory for molecules
   GetSetup(argv);			// read in setup file
   //InitUnits();				// initialize units for calculation
   //InitForcefield();			// initialize Lennard-Jones potential mixing rule

   system	=	0;		// for now 2/14/08, only one system

   //InitSample();			// initialize sampling

   nframe	=	-1;

   //------Initialize variable values------//

   for (i=0; i<180; i++) {
      orientdist[i]	=	0;	// chain orientation distribution
   }

   for (i=0; i<MAXNMOLSITES; i++) {
      xbeadpos[i]	=	0;	// crystal bead position
   }

   Nn		=	(long *) calloc(NSITES, sizeof(long));
   ntot		=	0;
   maxnmax	=	0;
   Rg2nucl	=	(float *) calloc(NSITES, sizeof(float));

   for (i=0; i<MAXNMOLSITES; i++) {	// segment length variables
      nlloop[i]		=	0;
      nltail[i]		=	0;
      nlbridge[i]	=	0;
      nlxseg[i]		=	0;
      nlfree[i]		=	0;
   }
   for (i=0; i<10; i++) {
      for (j=0; j<MAXNMOLSITES; j++) {
	 lsegdist[i][j]	=	0;
      }
   }

   //---------------------------//
   //	Start Data Processing	//
   //---------------------------//
   /*
   strcpy(filename, filein);
   strcat(filename, ".pre");
   if (!preflag) {
      if ((fpre=fopen(filename, "r"))==NULL )		// read .pre file
         Exit("lammps2hst", "main", "open .pre file failed.");
   }
   */

   for (ifile=0; ifile<nfiles; ifile++) {		// multiple input dump files

      fin	=	fopen(infile[ifile], "r");

      if (M2HDEBUG) printf("# Current dump file: %s\n", infile[ifile]);

      while (!feof(fin)) {

	 if (M2HDEBUG)	printf("\nDEBUG: Reading one configuration ...\n");

	 //---------------------------------------------//
	 //	Read one configuration from dump file	//
	 //---------------------------------------------//
	 if (!fgets(dummy, sizeof(dummy), fin)) {	// line 1 of each conf. in dump file
	    break;					// end of file
	 }
	 fscanf(fin, "%ld", &timestep);		fgets(dummy, sizeof(dummy), fin);	// line 2
	 fgets(dummy, sizeof(dummy), fin);						// line 3
	 fscanf(fin, "%ld", &nsites);		fgets(dummy, sizeof(dummy), fin);	// line 4

	 fgets(dummy, sizeof(dummy), fin);						// line 5
	 if (strstr(dummy, "xy"))	PBC = 3;	// PBC=3 for triclinic box

	 fscanf(fin, "%lf%lf", &xlo, &xhi);	if (PBC==3) fscanf(fin, "%lf", &xy); 	// line 6
	 fgets(dummy, sizeof(dummy), fin);
	 fscanf(fin, "%lf%lf", &ylo, &yhi);	if (PBC==3) fscanf(fin, "%lf", &xz); 	// line 7
	 fgets(dummy, sizeof(dummy), fin);
	 fscanf(fin, "%lf%lf", &zlo, &zhi);	if (PBC==3) fscanf(fin, "%lf", &yz);	// line 8
	 fgets(dummy, sizeof(dummy), fin);
	 fgets(dummy, sizeof(dummy), fin);						// line 9

	 // calculate box dimension, triclinic in general

printf("xy=%f xz=%f yz=%f\n", xy, xz, yz);
         /*PBC=1;//temp 1/22/2014
	 xy=0.0;
	 xz=0.0;
	 yz=0.0;*/

	 xlo	-=	MIN(0.0, MIN(xy, MIN(xz, xy+xz)));
	 xhi	-=	MAX(0.0, MAX(xy, MAX(xz, xy+xz)));
	 ylo	-=	MIN(0.0, yz);
	 yhi	-=	MAX(0.0, yz);

	 system	=	0;
	 BOX[system].lx	=	xhi-xlo;
	 BOX[system].ly	=	yhi-ylo;
	 BOX[system].lz	=	zhi-zlo;
	 BOX[system].xy	=	xy;
	 BOX[system].xz	=	xz;
	 BOX[system].yz	=	yz;


	 tmp1	=	MAX( MAX(BOX[system].lx, BOX[system].ly), BOX[system].lz);
	 tmp3	=	MIN( MIN(BOX[system].lx, BOX[system].ly), BOX[system].lz);
	 if ( fabs(BOX[system].lx-tmp1) > ZERO && fabs(BOX[system].lx-tmp3) > ZERO) {
	    tmp2	=	BOX[system].lx;
	 }
	 else if ( fabs(BOX[system].ly-tmp1) > ZERO && fabs(BOX[system].ly-tmp3) > ZERO) {
	    tmp2	=	BOX[system].ly;
	 }
	 else if ( fabs(BOX[system].lz-tmp1) > ZERO && fabs(BOX[system].lz-tmp3) > ZERO) {
	    tmp2	=	BOX[system].lz;
	 }
	 asphericity	=	tmp1 * tmp1 - 0.5*(tmp2*tmp2 + tmp3*tmp3);
	 asphericity	/=	(tmp1 + tmp2 + tmp3) * (tmp1 + tmp2 + tmp3) / 9;
    
         // read atom information

	 LENGTH		=	NSITES/NMOLS;		// monodisperse system for now (4/26/2008)

	 for (i=0; i<nsites; i++) {
	    fscanf(fin, "%ld", &id);
	    fscanf(fin, "%ld", &type);
	    fscanf(fin, "%lf%lf%lf %lf%lf%lf %d%d%d", &x, &y, &z, &vx, &vy, &vz, &nx, &ny, &nz);
	    fscanf(fin, "%lf", &tmp1);
	    fscanf(fin, "%d", &itmp1);
	    //fscanf(fin, "%d", &itmp2);
	    fgets(dummy, sizeof(dummy), fin);

	    id	--; 					// -1 because lammps index starts from 1
	    molid	=	(long) (id/LENGTH);
	    siteid	=	id % LENGTH;

            // box id and chain length
	    mol[molid].box	=	system;		// for now, only one system
	    mol[molid].nsites	=	LENGTH;		// for now, Jan/10/2010

	    // atom type 
	    mol[molid].type[siteid]	=	type - 1;	// -1 because lammps index starts from 1

	    // general triclinic box
	    mol[molid].p[siteid].x	=	x + nx*(BOX[system].lx) 
						  + ny*(BOX[system].xy) + nz*(BOX[system].xz);
	    mol[molid].p[siteid].y	=	y + ny*(BOX[system].ly) + nz*(BOX[system].yz);
	    mol[molid].p[siteid].z	=	z + nz*(BOX[system].lz);

	    // for density profile calculation
	    rsite[i].x	=	x;
	    rsite[i].y	=	y;
	    rsite[i].z	=	z;
    
	    // velocity
	    mol[molid].velx[siteid]	=	vx;
	    mol[molid].vely[siteid]	=	vy;
	    mol[molid].velz[siteid]	=	vz;

	    // atom potential energy
	    mol[molid].pe[siteid]	=	tmp1;
	    mol[molid].cna[siteid]	=	itmp1;

	 }	// one configuration read

	 // system information

	 for (i=0; i<NSYSTEMS; i++) {
	    NMols[i]	=	0;
	    NSites[i]	=	0;
	 }
	 for (moli=mol; moli<mol+NMOLS; moli++) {
	    if ( (i=moli->box) >= 0) {
	       NMols[i]	++;				// total # of mols in certain system
	       NSites[i]	+=	moli->nsites;	// total # of sites in certain system
	    }
	 }

	 for (moli=mol; moli<mol+NMOLS; moli++) {
	    for (i=0; i<moli->nsites; i++)  {
	       moli->flags[i]	=	1;		// activate all the sites on this processor
	       moli->parent[i]	=	i-1;		// initialize parent site
	    }
	    moli->flip		=	0;		// flip to the original direction
	    moli->origin	=	CenterofMass(moli);
	 }

	 //-----------------------------------------------------//
	 //	Skip repeated frames from different input files	//
	 //-----------------------------------------------------//
	 if (ifile>=1 && timestep == previous_timestep) {
	    continue;
	 }
	 previous_timestep	=	timestep;	// check repeat frames

	 //-----------------------------//
	 //	Check timestep range	//
	 //-----------------------------//
	 if (timestep < starttime) {		// starttime=-1 by default
	    continue;
	 }
	 if (endtime > 0 && endtime < timestep) {	// endtime=-1 by default
	    break;
	 }

	 //-------------------------------------//
	 //	Skip (dnframe - 1) frames	//
	 //-------------------------------------//
	 nframe	++;
	 if (nframe%dnframe)	continue;	// analyze every dnframe frames
	
	 //-----------------------------//
	 //	Perform analysis	// 
	 //-----------------------------//
	 for (i=0; i<NSYSTEMS; i++) {	// Convert other lengths
	    BOX[i].lbox		=	MIN(MIN(BOX[i].lx, BOX[i].ly), BOX[i].lz);
	    BOX[i].vol		=	BOX[i].lx * BOX[i].ly * BOX[i].lz;
	    BOX[i].rc		=	MIN(0.5*BOX[i].lbox, Rc);
	    BOX[i].rb		=	Rb;
	    BOX[i].rv		=	Rv;
	 }

	 radial("sample");		// sample radial distribution function

         //-------------------------------------//
	 //	Convert to Z-code input file	//
         //-------------------------------------//
	 
         //-----------------------------------------------------//
	 //	Calculate common neighborhood parameter (CNP)	//
         //-----------------------------------------------------//
	 atom_neighbor();
	 comm_neigh_para();

         for (moli=mol; moli<mol+NMOLS; moli++) {
	    for (i=0; i<moli->nsites; i++) {
	       if (moli->type[i]==1) {
		  printf("%f ", moli->pe[i]);
		  printf("%f ", moli->rmin[i]);
		  printf("%f ", moli->rmax[i]);
		  printf("%f ", moli->rave[i]);
		  printf("%f ", moli->cnp[i]);
		  printf("%d ", moli->nneigh[i]);
		  printf("%d\n", moli->cna[i]);
	       }
	       //printf("m_nn %d\n", moli->nneigh[i]);
	    }
	 }
	 //-------------------------------------//
	 //	Output configuration files	//
	 //-------------------------------------//

	 if (M2HDEBUG)	printf("DEBUG: Output configuration files ...\n");
	 // find min and max for coloring parameter

         if (xyzflag) {
	    output_xyzfile(fxyz);

	    tmp1	=	1.0e8;
	    tmp2	=	-1.0e8;
	    for (moli=mol; moli<mol+NMOLS; moli++) {
	       if (moli->type[0]==1 && displayatom(moli-mol)) {
		  tmp3	=	moli->cna[0];
		  tmp3	=	moli->nneigh[0];
		  tmp3	=	moli->rmin[0];
		  tmp3	=	moli->rmax[0]-moli->rmin[0];
		  tmp3	=	moli->cnp[0];
		  tmp3	=	moli->pe[0];

		  //tmp3	=	moli->cnp[0];
		  //if (tmp3 >50) tmp3=50;	// temporary code for cnp strangely large cnp

		  if (tmp1 > tmp3) {
		     tmp1 = tmp3;		// min
		  }
		  if (tmp2 < tmp3) {
		     tmp2 = tmp3;		// max
		  }
	       }
	    }

	    // output for coloring in VMD

	    for (moli=mol; moli<mol+NMOLS; moli++) {
	       tmp3	=	moli->cna[0];
	       tmp3	=	moli->nneigh[0];
	       tmp3	=	moli->rmin[0];
	       tmp3	=	moli->rmax[0]-moli->rmin[0];
	       tmp3	=	moli->cnp[0];
	       tmp3	=	moli->pe[0];
	       
	       if (moli->type[0]==1 && displayatom(moli-mol)) {
		  tmp3	=	0.7 * (tmp3 - tmp1)/(tmp2-tmp1);
	       }

               //if (moli->type[0]!=1)	tmp3 = 0.25;  // for cnp
               //if (moli->type[0]!=1)	tmp3 = 0.0;  // for pe
               if (moli->type[0]!=1)	tmp3 = 0.8;

               if (displayatom(moli-mol)) {
		  fprintf(fcolor, "%f ", tmp3);
               }
	       //printf("pe %f\n", tmp3);
	       //printf("cnp %f\n", tmp3);
	    }
	    fprintf(fcolor, "\n");

	 }
	 
      } 			// finish ONE input dump file

      fclose(fin);		// close current input dump file

   }				// finish ALL input dump files

   //-------------------------------------------------------------------//
   //	Output final analysis results after ALL frames processed	//
   //-------------------------------------------------------------------//
   if (M2HDEBUG)	printf("DEBUG: ALL FRAMES PROCESSED ...\n");

   //------Frame information------//

   printf("\n# OUTPUT AFTER ALL FRAMES ARE PROCESSED\n\n");
   printf("START TIMESTEP\t%d\n", starttime);
   printf("END TIMESTEP\t%d\n", endtime);
   printf("TOTAL FRAMES\t%d\n", nframe+1);
   printf("ANALYZE EVERY\t%d\n", dnframe);
   printf("ANALYZED FRAMES\t%d\n", nframe/dnframe+1);

   radial("print");		// print out radial distribution function

   //-------------------//
   //	Closing files	//
   //-------------------//
   if (M2HDEBUG)	printf("DEBUG: Close output files ...\n");

   prog_end	=	time(NULL);
   
   printf("\n# END OF OUTPUT FILE\n");
   printf("%s", asctime(localtime(&prog_end)));
   printf("\nTotal running time was %lf seconds.\n", difftime(prog_end, prog_start));

   if (xyzflag) {
      fclose(fxyz);
      fclose(fcolor);
   }

#ifdef myMPI
   MPI_Finalize();
#endif
   return	0;
}	
//------MAIN program ends------//


//======================//
//	SUBROUTINES	//
//======================//

//==============================================//
//	Output variables for each chain 	//
//	-- Rg, segment info. etc.		//
//	-- output format made similar		//
//	-- to .pre, so that they can		//
//	-- be easily merged			//
//==============================================//

//======================================================================//
//	output_pre(): write pre-analysis results for further analysis	//
//	              These pre-results should be basic but very	//
//		      time-consuming.  So by saving these results in	//
//		      a pre- file we can reuse them later without 	//
//		      calculating them every time.			//
//======================================================================//

//==============================================================//
//	read_pre(): read pre-analysis results, see output_pre()	//
//==============================================================//

//==============================================================//
//	output_xyzfile(): write configuration to .xyz file	//
//==============================================================//
void output_xyzfile(FILE *fPtr)
{
   molstruct	*moli;
   int		i;
   int		n;
   int		N;

   N	=	0;
   for (moli=mol; moli<mol+NMOLS; moli++) {
      n	=	moli-mol;
      if (displayatom(n)) {
	 N	++;
      }
   }

   fprintf(fPtr, "%d\n", N);
   fprintf(fPtr, "comments......\n");
   for (moli=mol; moli<mol+NMOLS; moli++) {

      n	=	moli-mol;

      if (displayatom(n)) {
	 for (i=0; i<moli->nsites; i++) {
	    fprintf(fPtr, "O %f %f %f\n", moli->p[i].x, moli->p[i].y, moli->p[i].z);
	 }
      }

   }
   fflush(fPtr);
   return;
}

//==============================================================//
//	output_carfile(): write configuration to .car file	//
//==============================================================//

//======================================================================//
//	output_pdbfile(): write configuration to pdb file and vmd files	//
//======================================================================//

//======================================================================//
//	output_conf(): write configuration to configuration file	//
//======================================================================//

//======================================================================//
//	output_Zinput(): write coord. as Z code input file (4/4/13)	//
//======================================================================//

int displayatom(int n)
{
   int	result;

   if ( (n<9600 && n/4/40%6==5 && (n%4==2 || n%4==3)) || 
        (n>=9600 && (n-9600)/4/41%6==0 && (n%4==0 || n%4==1)) ){ 
      result	=	1;
   }
   else {
      result	=	0;
   }
//   result	=	1;
   return	result;
}
