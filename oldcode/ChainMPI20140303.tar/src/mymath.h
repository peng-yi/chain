/*
    program:    mymath.h  
    author:     Peng Yi at MIT
    date:       October 22, 2006
    purpose:    header file for mymath.c
*/
#ifndef __MYMATH_HEADER
#define __MYMATH_HEADER

#ifdef __MYMATH_MODULE
#include "header.h"


#else


#endif

#endif
